---
"@ekx/unit": patch
---

add `--version`, `--help`, `--list`, `--short-filenames` options to CLI
