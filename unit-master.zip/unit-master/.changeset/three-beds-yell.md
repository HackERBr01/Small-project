---
"@ekx/unit": patch
---

Rename `--silent` switch to `--quiet`
