#define UNIT_MAIN
#define UNIT_TESTING
#define UNIT__SELF_TEST

#include "unit.h"
